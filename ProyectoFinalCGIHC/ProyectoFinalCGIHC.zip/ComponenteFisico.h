#pragma once

#include <glm.hpp>

// Componente de f�sica para entidades
class ComponenteFisico {
public:
    ComponenteFisico();
    
    // Aplicar f�sica (gravedad y colisi�n)
    void aplicarFisica(float deltaTime, float nivelSuelo, glm::vec3& posicion, const glm::vec3& posicionInicial);
    
    // Salto de la entidad
    void saltar(float fuerzaSalto);
    
    // Verificar si est� en el suelo
    bool estaEnSuelo() const { return enSuelo; }
    
    // Habilitar/deshabilitar f�sica
    void habilitar(bool habilitar) { habilitada = habilitar; }
    bool estaHabilitada() const { return habilitada; }

    glm::vec3 velocidad;    // Velocidad del objeto
    float gravedad;         // Fuerza de gravedad
    
private:
    bool habilitada;        // Si la f�sica est� activa
    bool enSuelo;          // Si el objeto est� tocando el suelo
};
